from matrix import *  # Importing matrix library

defines.images_urls = [  # Setting images urls
	'https://raw.githubusercontent.com/Akenland/Revival/1.14/assets/minecraft/textures/block/grass_block_side.png',
	'https://raw.githubusercontent.com/Akenland/Revival/1.14/assets/minecraft/textures/block/ice.png']

def setup():
	pass

def frame():
	delay(3)  # Delay for 3 seconds
	url = random.choice(defines.images_urls)  # Choicing random url from the list
	image = Image.from_url(url, Image.png)  # Parsing image from url
	show_image(image)  # Displaying image on the matrix
