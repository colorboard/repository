from time import sleep


def setup():
	print('марио!!!!!!!!')

def frame():
	print('игра игра игра')
	sleep(1)
