from matrix import *  # Importing matrix library

def setup():
	pixels.fill(colors.black)

def frame():
	pixels.put_pixel(random.randint(0, 16), random.randint(0, 16), colors.white)
	bridge.strip.show()
